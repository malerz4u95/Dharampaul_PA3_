package com.company;

import java.security.SecureRandom;

public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
